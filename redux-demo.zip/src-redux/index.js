import React from 'react';
import {render} from 'react-dom';
import 'antd/dist/antd.css';
import store from './redux/store';
import App from './components/App';

const myRender = ()=>(
    render(<App  store={store}/>, document.getElementById('root'))
)
myRender();

store.subscribe(myRender);


