import * as type from '../actionTypes';
const reducers = (state=0,action)=>{
    switch(action.type){
        case type.INCREMENT:state=state+action.data;
        break;
        case type.DECREMENT:state = state-action.data;
        break;
    }
    return state;
}

export default reducers;