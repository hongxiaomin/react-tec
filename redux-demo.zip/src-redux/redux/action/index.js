import * as type from '../actionTypes';

export const increment = (data)=>({type:type.INCREMENT,data:data});
export const decrement = (data)=>({type:type.DECREMENT,data:data});
