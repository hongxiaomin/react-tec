import React,{Component} from 'react';
import { Layout ,Select,Button  } from 'antd';
import {increment,decrement} from '../redux/action';
import '../style/index.css'
const { Header, Content } = Layout;
const Option = Select.Option;

export default class App extends Component{
    constructor(){
        super();
        this.state={
            selectVale:1,
        }
    }
    handleChange=(value)=>{
        this.setState({
            selectVale:value*1
        })
    }
    increment=()=>{
        let val = this.state.selectVale;
        this.props.store.dispatch(increment(val));
    }
    decrement=()=>{
        let val = this.state.selectVale;
        this.props.store.dispatch(decrement(val));
    }
    incrementIfOdd=()=>{
        let val = this.state.selectVale;
        if(this.props.store.getState()%2===1){
            this.props.store.dispatch(increment(val));
        }
    }
    incrementAsync=()=>{
        let val = this.state.selectVale;
        setTimeout(()=>{
            this.props.store.dispatch(increment(val));
        },1000)
    }
    render(){
        return (
            <Layout className="layout">
                <Header>
                    <h2 className="title">Click {this.props.store.getState()} Times</h2>
                </Header>
                <Content style={{ padding: '0 50px' }}>
                    <div style={{ background: '#fff', padding: 24, minHeight: 280 }}>
                        <Select defaultValue="1" style={{ width: 120 }} onChange={this.handleChange}>
                            <Option value="1">1</Option>
                            <Option value="2">2</Option>
                            <Option value="3" >3</Option>
                            <Option value="5">5</Option>
                        </Select>
                        <Button type="primary" className="account-btn" onClick={this.increment}>+</Button>
                        <Button type="primary" className="account-btn" onClick={this.decrement}>-</Button>
                        <Button type="primary" className="account-btn" onClick={this.incrementIfOdd}>increment if odd</Button>
                        <Button type="primary" className="account-btn" onClick={this.incrementAsync}>increment async</Button>
                    </div>
                </Content>
            </Layout>
        )
    }
}