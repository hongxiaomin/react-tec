import {connect} from 'react-redux';
import {increment,decrement,changeVal,incrementAsync} from '../../my-redux/action';
import Counter from '../../components/Counter';
const mapStateToProps = (state)=>({
    count:state.count,
    selectNum:state.selectNum
})
const mapDispatchToProps = (dispatch)=>({
    increment:(data)=>{dispatch(increment(data))},
    decrement:(data)=>{dispatch(decrement(data))},
    changeVal:(data)=>{dispatch(changeVal(data))},
    incrementAsync:(data)=>{dispatch(incrementAsync(data))}
})
export  default connect(mapStateToProps,mapDispatchToProps)(Counter)