import React,{Component} from 'react';
import {Layout ,Select,Button} from "antd";
import '../../style/index.css'
const { Header, Content } = Layout;
const Option = Select.Option;

const Counter =(props)=>{
    const handleChange=(value)=>{
        props.changeVal(value*1);
    }
    const increment=()=>{
        props.increment(props.selectNum);
    }
    const decrement=()=>{
        props.decrement(props.selectNum);
    }
    const incrementIfOdd=()=>{
        if(props.count%2===1){
            props.increment(props.selectNum);
        }
    }
    const incrementAsync=()=>{
        props.incrementAsync(props.selectNum);
    }
    return (
        <Layout className="layout">
            <Header>
                <h2 className="title">Click {props.count} Times</h2>
            </Header>
            <Content style={{ padding: '0 50px' }}>
                <div style={{ background: '#fff', padding: 24, minHeight: 280 }}>
                    <Select defaultValue="1" style={{ width: 120 }} onChange={handleChange}>
                        <Option value="1">1</Option>
                        <Option value="2">2</Option>
                        <Option value="3" >3</Option>
                        <Option value="5">5</Option>
                    </Select>
                    <Button type="primary" className="account-btn" onClick={increment}>+</Button>
                    <Button type="primary" className="account-btn" onClick={decrement}>-</Button>
                    <Button type="primary" className="account-btn" onClick={incrementIfOdd}>increment if odd</Button>
                    <Button type="primary" className="account-btn" onClick={incrementAsync}>increment async</Button>
                </div>
            </Content>
        </Layout>
    )
}
export default Counter;