import * as type from '../actionTypes';
const countState={
    count:0,
    selectNum:1
}
const increment = (state,{data})=>{
    let {count} = state;
    count = count+data;
    return {...state,count};
}
const decrement = (state,{data})=>{
    let {count} = state;
    count = count-data;
    return {...state,count};
}
const changeVal = (state,{data})=>{
    let {selectNum} = state;
    selectNum = data;
    return  {...state,selectNum};
}

const reducer = {
    [type.INCREMENT]:increment,
    [type.DECREMENT]:decrement,
    [type.CHANGEVAL]:changeVal
}

const options = (state=countState,action)=>{
    let nextState = state;
    if(reducer[action.type]){
        nextState = reducer[action.type](state,action);
    }
    return nextState;
}

export default options;