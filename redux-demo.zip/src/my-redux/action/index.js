import * as type from '../actionTypes';

export const increment = (data)=>{ console.log(data); return ({type:type.INCREMENT,data:data})};
export const decrement = (data)=>({type:type.DECREMENT,data:data});
export const changeVal = (data)=>({type:type.CHANGEVAL,data:data});
export const incrementAsync = (data)=>{
    return dispatch =>{
        setTimeout(()=>{
            dispatch(increment(data));
        },1000)
    }
};