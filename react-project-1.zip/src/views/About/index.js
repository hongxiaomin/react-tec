import React,{Component} from 'react';
export default class About extends Component{
    constructor(){
        super();
    }
    render(){
        return (
            <div>
                这是About组件
            </div>
        )
    }
}