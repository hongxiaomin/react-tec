import React,{Component} from 'react';
import {NavLink,Switch,Route,Redirect} from 'react-router-dom';
import News from './News';
import Message from './Message';
import NewsDetail from './NewsDetail';
export default class Home extends Component{
    constructor(){
        super();
    }
    render(){
        return (
            <div>
                <h2>Home组件内容</h2>
                <div className="home-navbar">
                    <NavLink to="/home/news">news</NavLink>
                    <NavLink to="/home/messages">messages</NavLink>
                </div>

                <div className="home-content">
                    <Switch>
                        <Route path="/home/news" component={News}></Route>
                        <Route path="/home/messages" component={Message}></Route>
                        <Redirect to="/home/news"></Redirect>
                    </Switch>
                </div>
            </div>
        )
    }
}