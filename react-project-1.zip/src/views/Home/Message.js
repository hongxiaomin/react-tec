import React,{Component} from 'react';
import axios from 'axios'
export default class Message extends Component{
    constructor(){
        super();
        this.state={
            list:[],
            loading:false
        }
    }
    componentDidMount() {
        this.setState({
            loading:true
        });
        axios.get('https://api.github.com/search/users?q=xx').then(res=>{
            let data=res.data;
            console.log(data);
            this.setState({
                list:data.items,
                loading:false
            })
        }).catch(err=>{
            console.log(err);
            this.setState({
                loading:false
            })
        })
    }

    render(){
        return (
            <div>
                {
                    this.state.loading?'Loading Result...':(
                        <ul className="message-wrapper">
                            {
                                this.state.list.map(item=>{
                                    return(
                                        <li className="message-item" key={item.id}>
                                            <a href={item.html_url}>
                                                <img src={item.avatar_url} alt=""/>
                                                <h3>{item.score}</h3>
                                            </a>
                                        </li>
                                    )
                                })
                            }
                        </ul>
                    )
                }

            </div>
        )
    }
}