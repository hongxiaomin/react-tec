import React,{Component} from 'react';
import {Link,Route} from 'react-router-dom';
import NewsDetail from './NewsDetail';
import data from '../../json/news';
export default class News extends Component{
    constructor(){
        super();
        this.state={
            news:data.list
        }
    }
    pushDetail=(id)=>()=>{
        this.props.history.push(`/home/news/${id}`);
    }
    replaceDetail =(id)=>()=>{
        this.props.history.replace(`/home/news/${id}`);
    }
    render(){
        let {news} = this.state;
        return (
            <div className="news-wrapper">
                <ul className="list-group">
                    {
                        news.map(item=>{
                            return (
                                <li className="list-group-item" key={item.id}>
                                    <Link to={`/home/news/${item.id}`}>
                                        {item.title}
                                    </Link>
                                    <button onClick={this.pushDetail(item.id)}>查看(push)</button>
                                    <button onClick={this.replaceDetail(item.id)}>查看(replace)</button>
                                </li>
                            )
                        })
                    }
                </ul>

                <div className="news-detail">
                    <Route path="/home/news/:id" component={NewsDetail}></Route>
                </div>
            </div>
        )
    }
}