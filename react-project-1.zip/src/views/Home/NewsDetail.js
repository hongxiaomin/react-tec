import React,{Component} from 'react';
import data from '../../json/news';

export default class NewsDetail extends Component{
    constructor(){
        super();
        this.state= {
            currentNews: null
        }
    }
    render(){
        let id = this.props.match.params?this.props.match.params.id:'';
        let currentNews =data.list.filter(item=>{
            return item.id == id;
        })[0];
        return (
            <div>
                {
                    currentNews?(
                        <div className="detail-content">
                            <h2>{currentNews.title}</h2>
                            <p>
                                {currentNews.content}
                            </p>
                        </div>
                    ):null
                }
            </div>
        )
    }
}