import React,{Component} from 'react';
import {NavLink} from 'react-router-dom';
import PropTypes from 'prop-types';
export default class MyNavLink extends Component{
    constructor(props){
        super(props);
    }
    static propTypes = {
        to:PropTypes.string.isRequired,
        title:PropTypes.string.isRequired,
    }
    render(){
        let {to,myStyle,title} = this.props;
        return (
            <NavLink to={to} activeClassName={myStyle?myStyle:'active'} className="list-group-item">{title}</NavLink>
        )
    }
}