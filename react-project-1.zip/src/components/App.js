import React,{Component} from 'react';
import {NavLink,Route,Redirect,Switch} from 'react-router-dom';
import Home from '../views/Home';
import About from '../views/About';
import MyNavLink from './MyNavLink';
import './style/index.css';
export default class App extends Component{
    constructor(){
        super();
        this.state={
            navMenus:[
                {
                    to:'/home',
                    title:'Home'
                },
                {
                    to:'about',
                    title:'About'
                }
            ]
        }
    }
    render(){
        return (
            <div className="container mt-md-5">
                <div className="row">
                    <div className="offset-md-2 col-md-8">
                        <div className="page-header">
                            <h2>React Router Demo</h2>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-4">
                        <div className="list-group">
                            <MyNavLink to="/home"  title="Home"/>
                            <MyNavLink to="/about" title="About"/>
                        </div>
                    </div>
                    <div className="col-md-8">
                        <div className="container">
                            <Switch>
                                <Route path="/home" component={Home}></Route>
                                <Route path="/about" component={About}></Route>
                                <Redirect to="/home"></Redirect>
                            </Switch>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}