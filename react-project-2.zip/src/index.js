import React from 'react';
import {render} from 'react-dom';
import 'antd/dist/antd.css'
import {BrowserRouter} from 'react-router-dom';

import App from './components/App';

const myRender = ()=>(
    render(<BrowserRouter>
        <App/>
    </BrowserRouter>,document.getElementById('root'))
)

myRender()

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
