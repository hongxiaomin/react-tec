# 评论列表的功能
## 拆分功能点，确定组件
1. 应用主组件：Comment
2. 添加评论的组件： AddComment
3. 显示评论列表的组件： CommentList
4. 评论个体： CommentItem

## 数据源存放的位置：Comment
## 将静态页转为react组件
    1. class--->className
    2.表单项的结束标签
    3.style == {{}}
## 划分每个组件对应的内容



# fetch 请求参考
[https://segmentfault.com/a/1190000003810652]