import React,{Component} from 'react';
import axios from 'axios';
import  qs from 'qs';
// import fetch from 'fetch';
require('es6-promise').polyfill();
require('isomorphic-fetch');
export default class ReactAjax extends Component{
    constructor(){
        super();
        this.state={
            list:[],
            loading:false,
        }
    }
    componentDidMount=()=> {
        // this.setState({
        //     loading:true
        // });
        // axios.post('https://172.26.22.192/troilalive/live/2_0/queryHall',
        //     qs.stringify({isSquareTop:1,}),
        //     {headers:{token:'F6999A88E34CED2BA8A3EF280DE1928F'}
        // }).then(res=>{
        //     if(res.status==200){
        //         let data = res.data;
        //         this.setState({
        //             list:data.vo.list,
        //             loading:false
        //         })
        //     }
        // }).catch(err=>{
        //     this.setState({loading:false})
        // })


        let formData = new FormData();
        formData.append("isSquareTop",1);
        fetch('https://172.26.22.192/troilalive/live/2_0/queryHall',{
            method:'POST',
            headers:{token:'F6999A88E34CED2BA8A3EF280DE1928F'},
            body:formData
        }).then(response=>{
            return response.json();
        }).then(data=>{
            let list = data.vo.list;
            this.setState({
                list,
                loading:false
            })
        }).catch(err=>{
            console.log(err);
            this.setState({
                loading:false
            })
        })

    }
    render(){
        return (
            <div>
                <h1>React ajax 请求之axios应用</h1>
                {
                    this.state.loading?'Loading...':(
                        <ul>
                            {
                                this.state.list.map(item=>(
                                    <li key={item.id}>
                                        <h2>{item.liveTheme}</h2>
                                    </li>
                                ))
                            }
                        </ul>
                    )
                }
            </div>
        )
    }
}