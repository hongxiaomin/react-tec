import React,{Component} from 'react';
export default class ComponentLifeCycle extends Component{
    constructor(){
        super();
        this.state={
            isLick:true
        }
        alert('constructor');
    }
    componentWillReceiveProps(nextProps, nextContext) {
        alert('componentWillReceiveProps');
    }
    componentWillMount(){
        alert('componentWillMount');
    }
    componentDidMount(){
        alert('componentDidMount');
    }
    shouldComponentUpdate(){
        alert('shouldComponentUpdate');
        return true;
    }
    componentWillUpdate(){
        alert('componentWillUpdate');
    }
    componentDidUpdate(){
        alert('componentDidUpdate');
    }
    componentWillUnmount() {
        alert('componentWillUnmount');
    }
    handleChange=()=>{
        this.setState({
            isLick:!this.state.isLick
        })
    }
    render(){
        alert('render');
        return (
            <div>
                <h1 onClick={this.handleChange}>{this.state.isLick?'我喜欢React':'我不喜欢React'}</h1>
                <p>我是{this.props.name}</p>
            </div>
        )
    }
}