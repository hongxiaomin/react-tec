import React,{Component} from 'react';
import SearchForm from './SearchForm';
import SearchList from './SearchList';
import './index.css';

export default class Search extends Component{
    constructor(){
        super();
        this.state={
            searchValue:''
        }
    }
    handleSearch=(value)=>{
        this.setState({
            searchValue:value
        })
    }
    render(){
        return (
            <div className="search-wrapper">
                <h1>Git用户名查询</h1>
                <SearchForm handleSearch={this.handleSearch}/>
                <SearchList searchValue={this.state.searchValue}/>
            </div>
        )
    }
}