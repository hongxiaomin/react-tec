import React,{Component} from 'react';
export default class SearchForm extends Component{
    constructor(){
        super();
    }
    handleClick=()=>{
        let value = this.keyword.value;
        this.props.handleSearch(value);
    }
    render(){
        return (
            <div className="search-form">
                <input type="text" ref={ref=>this.keyword=ref}/>
                <button onClick={this.handleClick}>搜索</button>
            </div>
        )
    }
}