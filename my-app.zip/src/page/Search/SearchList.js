import React,{Component} from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';
export default class SearchList extends Component{
    constructor(){
        super();
        this.state={
            list:[],
            loading:false,
        }
    }
    //声明组件类的静态资源
    static propTypes = {
        searchValue:PropTypes.string.isRequired
    }
    componentWillReceiveProps(nextProps, nextContext) {
        console.log(nextProps);
        this.setState({
            loading:true
        });
        let searchValue = nextProps.searchValue;
        let url = `https://api.github.com/search/users?q=${searchValue}`;
        axios.get(url).then(res=>{
            console.log(res);
            if(res.status==200){
                let data = res.data;
                this.setState({
                    list:data.items,
                    loading:false
                })
            }
        }).catch(err=>{
            console.log(err);
            this.setState({
                loading:false
            })
        })
    }

    render(){
        return (
            <div className="search-list">
                {
                    this.state.loading?'Loading Result...':(
                        <ul>
                            {
                                this.state.list.map(item=>{
                                    return (
                                        <li key={item["id"]}>
                                            <a href={item.html_url} target="_blank">
                                                <img src={item["avatar_url"]} alt=""/>
                                            </a>
                                        </li>
                                    )
                                })
                            }
                        </ul>
                    )
                }

            </div>
        )
    }
}


