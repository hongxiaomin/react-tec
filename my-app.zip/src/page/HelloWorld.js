import React,{Component} from 'react';
import './index.css'
class HelloWorld extends Component{
    constructor(){
        super();
        this.state={
            langStatus:true,
        }
    }
    handleClick=()=>{
       this.setState({
           langStatus:!this.state.langStatus
       })

    }
    render(){
        let msg = this.state.langStatus?'Hello World!':'你好，世界！';
        return <div className="wrapper">
            <h1>{msg}</h1>
            <button onClick={this.handleClick}>点我试试</button>
        </div>
    }
}
export default HelloWorld;