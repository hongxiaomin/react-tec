import React,{Component} from 'react';
export const MyComponent1 = (props)=>(
    <div>
        {props.message}
    </div>
);
export class MyComponent2 extends Component{
    render(){
        return (
            <div>
                {this.props.message}
            </div>
        )
    }
}

