import React,{Component} from 'react';
import AddComment from './AddComment';
import CommentList from './CommentList';
import './style/index.css';
import PubSub from 'pubsub-js';

class Comment extends Component {
    constructor(){
        super();
        this.state={
            commentList:[],
            commentNum:0,
        }
    }
    handleAddItem=(val)=>{
        let id = ++this.state.commentNum;
        console.log(id);
        val={id,...val};
        let commentList = [...this.state.commentList,val];
        this.setState({
            commentList,
            commentNum:id
        })
    }
    handleDeleteItem=val=>()=>{
        console.log(val);
        console.log(this.state.commentList);
       let commentList = this.state.commentList.filter(item=>{
           return item.id!==val.id;
       })
        this.setState({commentList})
    }

    render(){
        return (
            <div className="comment-wrapper">
                <h1 className="comment-title">
                    请发表对React的评论
                </h1>
                <div className="comment-content">
                    <AddComment handleAddItem={this.handleAddItem}/>
                    <CommentList commentList={this.state.commentList} handleDeleteItem={this.handleDeleteItem} />
                </div>
            </div>
        )
    }
}
export default Comment;

