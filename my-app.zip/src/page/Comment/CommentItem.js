import React,{Component} from 'react';
import PubSub from 'pubsub-js';

export default class CommentItem extends Component{
    constructor(){
        super();
    }
    render(){
        let {data,handleDelete} = this.props;
        return (
            <li className="comment-list-item">
                <span>{data.name}说:</span>
                <p>{data.content}</p>
                <button onClick={handleDelete(data)}>删除</button>
            </li>
        )
    }
}