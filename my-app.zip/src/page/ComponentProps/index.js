import React,{Component} from 'react';
import {Person} from './PropItem';

export default class ComponentProps extends Component{
    constructor(props){
        super(props);
        this.state={
            list:[
                {
                    name:'张三',
                    sex:'男',
                    age:15
                },
                {
                    name:'李四',
                    age:20
                }
            ]
        }
    }
    render(){
        return (
            <div className="wrapper">
                {
                    this.state.list.map((item,index)=>(
                        <Person {...item} key={index}/>
                    ))
                }
            </div>
        )
    }
}