import  React,{ReactPropTypes} from 'react';
import PropTypes from 'prop-types';
export const Person = props=>(
    <ul>
         <li>
             姓名:{props.name}
         </li>
         <li>
             性别:{props.sex}
         </li>
         <li>
             年龄:{props.age}
         </li>
     </ul>
);

// export class Person extends React.Component{
//     constructor(props){
//         super(props);
//     }
//     render(){
//         return (
//             <ul>
//                 <li>
//                     姓名:{this.props.name}
//                 </li>
//                 <li>
//                     性别:{this.props.sex}
//                 </li>
//                 <li>
//                     年龄:{this.props.age}
//                 </li>
//             </ul>
//         )
//     }
// }
//规定传入的数据类型和必要性
Person.propTypes={
  name:PropTypes.string.isRequired,
    age:PropTypes.number.isRequired,
};
//组件类的默认属性
Person.defaultProps={
    sex:'女',
    name:'Luck',
    age:18
};
