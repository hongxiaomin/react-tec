import React,{Component} from 'react';
import PubSub from 'pubsub-js';

export default class CommentItem extends Component{
    constructor(){
        super();
    }
    handleDelete=(data)=>{
        PubSub.publish('del',this.props.data);
    }
    render(){
        let {data} = this.props;
        return (
            <li className="comment-list-item">
                <span>{data.name}说:</span>
                <p>{data.content}</p>
                <button onClick={this.handleDelete}>删除</button>
            </li>
        )
    }
}