import React,{Component} from 'react';
export default class AddComment extends Component{
    handleAdd=()=>{
        let name = this.name.value;
        let content = this.content.value;
        if(!name||!content){
            alert('用户名或评论为空');
            return;
        }
        this.props.handleAddItem({name,content});
        this.name.value="";
        this.content.value="";
    }
    render(){
        return (
            <div className="comment-add">
                <div className="comment-add-item">
                    <label>用户名</label>
                    <input type="text" placeholder="用户名" ref={ref=>this.name=ref}  />
                </div>
                <div className="comment-add-item">
                    <label>评论内容</label>
                    <textarea  placeholder="评论内容" ref={ref=>this.content=ref}/>
                </div>
                <div className="comment-add-btn">
                    <button onClick={this.handleAdd}>提交</button>
                </div>
            </div>
        )
    }
}