 import React,{Component} from 'react';
 import CommentItem from './CommentItem';
 export default class CommentList extends Component{
     constructor(){
         super();
     }
     render(){
         let {commentList,handleDeleteItem}=this.props;
         return (
             <div className="comment-list-wrapper">
                 <h2>评论回复:</h2>
                 <ul className="comment-list">
                     {
                         commentList.map((item,index)=>{
                             return <CommentItem key={index} data={item}/>
                         })
                     }
                 </ul>
             </div>
         )
     }
 }