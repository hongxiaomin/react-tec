import React,{Component} from 'react';
class DoList extends Component{
    constructor(){
        super();
        this.state={
            list:['jQuery','HTML5','Mobile','JavaScript','Node']
        }
    }
    render(){
        return (<div>
            <ul>
                {this.state.list.map((item,index)=>(
                    <li key={index}>
                        {item}
                    </li>
                ))}
            </ul>
        </div>)
    }
}

export default DoList;
