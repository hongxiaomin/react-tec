import React,{Component} from 'react';
export default class ComponentRef extends Component{
    constructor(){
        super();
        this.handleClick=this.handleClick.bind(this);
    }
    handleClick(){
      alert(this.msgInput.value);
    }
    handleBlue=()=>{
        alert(this.msgBlur.value);
    }
    render(){
        return (
            <div className="ref-wrapper">
                <input type="text" ref={input=>this.msgInput=input}/>
                <button onClick={this.handleClick}>提示输入数据</button>
                <input type="text" ref={input=>this.msgBlur=input} placeholder="失去焦点提示数据" onBlur={this.handleBlue}/>
            </div>
        )
    }
}