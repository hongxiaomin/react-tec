import React,{Component} from 'react';
export default class ReactKey extends Component{
    constructor(){
        super();
        this.state={
            list:[
                {
                    id:1,
                    name:'小草'
                },
                {
                    id:2,
                    name:'小花'
                }
            ]
        }
    }
    handleAdd=()=>{
        let item = {id:3,name:'小树'};
        let newList =[item,...this.state.list];
        this.setState({
            list:newList
        })
    }
    render(){
        return (
            <div>
                <ul>
                    {
                        this.state.list.map(item=>{
                            return (
                                <li key={item.id}>{item.name}<input type="text"/></li>
                            )
                        })
                    }
                </ul>
                <ul>
                    {
                        this.state.list.map((item,index)=>{
                            return (
                                <li key={index}>{item.name}<input type="text"/></li>
                            )
                        })
                    }
                </ul>
                <button onClick={this.handleAdd}>增加一个</button>
            </div>
        )
    }
}