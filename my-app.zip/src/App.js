import React, { Component } from 'react';
import './App.css';
import Comment from './page/Comment';
import CommentPubSub from './page/CommentPubSub';
import {MyComponent1,MyComponent2} from './page/Components_basic';
import HelloWorld from './page/HelloWorld';
import ComponentProps from './page/ComponentProps';
import ComponentRef from './page/ComponentRef';
import ComponentLifeCycle from './page/ComponentLifeCycle';
import ReactAjax from './page/ReactAjax';
import ReactKey from './page/ReactKey';
import Search from './page/Search';

class App extends Component {
    constructor(){
        super();
        this.state={
            name:'张三'
        }
    }
    handleClick=()=>{
        this.setState({
            name:'李四'
        })
    }
  render() {
    return (
      <div className="App">
          <Comment/>
          {/*<CommentPubSub/>*/}
          {/*<MyComponent1 message="Hello World!"/>*/}
          {/*<MyComponent1 message="你好！"/>*/}
          {/*<HelloWorld/>*/}
          {/*<ComponentProps/>*/}
          {/*<ComponentRef/>*/}
          {/*<button onClick={this.handleClick}>改变name</button>*/}
          {/*<ComponentLifeCycle name={this.state.name}/>*/}
          {/*<ReactAjax/>*/}
          {/*<ReactKey/>*/}
          {/*<Search/>*/}
      </div>
    );
  }
}

export default App;



